#include "Board.h"
#include "Random.h"
#include <iostream>
#include "TextureManager.h"
#include "Tile.h"
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
using namespace std;



Board::Board(unsigned int boardWidth, unsigned int boardHeight) {
    vector<vector<Tile>> gameBoardVector;
    for (int i = 0; i < boardWidth; i++) {
        vector<Tile> gameBoardSubVector;
        for (int j = 0; j < boardHeight; j++) {
            Tile newTile;
            gameBoardSubVector.push_back(newTile);
            gameBoardSubVector.clear();
        }
        gameBoardVector.push_back(gameBoardSubVector);
    }
    /*gameBoardVector.resize(boardWidth, boardHeight);
    for (int i = 0; i < boardWidth; i++) {
        vector<Tile> gameBoardVector;
        for (int j = 0; j < boardHeight; j++) {
            Tile tile;
            gameBoardVector[i].push_back(tile);
        }
    }*/
}
